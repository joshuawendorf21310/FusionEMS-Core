# FusionEMS Quantum Skeleton

This repository contains a **skeleton implementation** of the FusionEMS Quantum platform.  It is **not a full implementation**, but it provides a high‑level scaffold for the major architectural components discussed in our planning session.  Use this as a starting point for development and iterate on each module according to the detailed tasks laid out in the master build task list.

## Repository Structure

- `app/main.py` – Entry point for the FastAPI application.  Sets up the API, WebSocket endpoint and health check.
- `app/core` – Core utilities and shared dependencies.
- `app/ems` – Skeleton for the EMS ePCR (TransportLink) module.
- `app/crew` – Skeleton for the CrewLink module.
- `app/billing` – Skeleton for the Billing module.
- `app/scheduling` – Skeleton for the Scheduling module.
- `app/fire` – Skeleton for the Fire module.
- `app/cad` – Skeleton for the Computer‑Aided Dispatch module.
- `app/patient_portal` – Skeleton for patient bill lookup and payment functionality.
- `app/auth_rep` – Skeleton for the Authorization Representative functionality.
- `cloudformation/root.yml` – A baseline CloudFormation template for deploying the infrastructure (VPC, RDS, Redis, ECS, ALB, ACM, Route 53, etc.).  This template is incomplete and must be extended to include all resources required for your production environment.

## Requirements

- Python 3.11+
- FastAPI, Uvicorn and Redis library.  Install via `pip install -r requirements.txt` (see below).

## Running Locally

Create a virtual environment and install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
pip install fastapi[all] redis
```

Start the development server:

```bash
uvicorn app.main:app --reload
```

The health check endpoint is available at `http://localhost:8000/health` and a WebSocket endpoint at `ws://localhost:8000/ws`.

## Next Steps

This skeleton provides only the most basic structure:

1. Define Pydantic schemas for each module (ePCR, billing, scheduling, etc.).
2. Implement database models and repository patterns for persistence (PostgreSQL via SQLAlchemy, asyncpg or similar).
3. Build out the validation engine for NEMSIS compliance, including code‑set enforcement and XML export.
4. Implement real‑time event broadcasting via Redis pub/sub and integrate with the WebSocket endpoint.
5. Flesh out the CloudFormation template to provision all required AWS resources (ECS Fargate, RDS Multi‑AZ, ElastiCache Redis, ACM, WAF, SES, etc.).
6. Develop the front‑end using your preferred framework (React/Next.js recommended) to consume the API and provide the “Ultra God” user experience.
7. See the `tasks_list.md` file in the project root for a detailed breakdown of every phase and task required to complete the platform.

This scaffold is designed to be extended module by module.  Keep your implementation modular and well‑tested as you build towards a production‑ready, certification‑compliant EMS platform.