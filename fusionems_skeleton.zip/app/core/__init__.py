# Core utilities and shared dependencies for the FusionEMS Quantum platform.

"""
The `core` package contains shared types, base classes and helper functions used
throughout the FusionEMS Quantum platform.  For example, configuration
management, database session utilities, authentication helpers, and common
exception classes should live here.

This module is currently empty and serves as a placeholder.  See the master
task list for instructions on how to build out the core infrastructure.
"""
