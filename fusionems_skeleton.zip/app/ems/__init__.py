# EMS (ePCR / TransportLink) module placeholder

"""
The `ems` package will implement the electronic patient care reporting (ePCR)
functionality for TransportLink.  This includes data models, Pydantic
schemas, validation logic enforcing the NEMSIS data dictionary, a
validation engine that ensures all required and conditional elements are
present, code‑set enforcement, null value handling, and XML export for
state and national submission.

In addition, this package should expose FastAPI routers for creating,
updating and exporting incidents, patients, vitals, interventions,
narratives and signatures.  See the master task list for detailed
requirements.
"""
