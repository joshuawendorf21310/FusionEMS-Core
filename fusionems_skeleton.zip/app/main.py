"""
Entry point for the FusionEMS Quantum API.

This file defines a FastAPI application with a basic health check endpoint and a WebSocket
handler.  In a full implementation the API would include routes for each domain
module (ePCR, billing, scheduling, crew management, etc.).
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends
from fastapi.middleware.cors import CORSMiddleware
from typing import List


def get_application() -> FastAPI:
    """
    Construct and configure the FastAPI application.

    This function exists to isolate app creation logic and make unit testing easier.
    """
    app = FastAPI(title="FusionEMS Quantum API", version="0.1.0")

    # CORS configuration – adjust allowed origins for your deployment
    origins = [
        "http://localhost",
        "http://localhost:3000",
        # Add your production domains here
    ]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    return app


app = get_application()


@app.get("/health")
async def health_check() -> dict[str, str]:
    """
    Basic health check endpoint used by load balancers and monitoring tools.
    Returns a simple status dictionary.
    """
    return {"status": "ok"}


class ConnectionManager:
    """
    Manages WebSocket connections for broadcasting messages.

    In a full production system this would integrate with Redis pub/sub to
    distribute events across multiple workers.  This skeleton keeps
    connections in memory and only broadcasts within a single process.
    """
    def __init__(self) -> None:
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket) -> None:
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: str) -> None:
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except WebSocketDisconnect:
                self.disconnect(connection)


manager = ConnectionManager()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket) -> None:
    """
    Handle incoming WebSocket connections.

    Clients can send messages which will be broadcast to all connected
    clients.  In a full implementation the server would listen to
    Redis pub/sub channels and push events to the client as they occur.
    """
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # Echo incoming messages back to all clients.  Replace this
            # with calls to your event bus when integrating with Redis.
            await manager.broadcast(f"Message from client: {data}")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception:
        manager.disconnect(websocket)
        raise