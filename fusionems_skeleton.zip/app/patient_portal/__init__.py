# Patient Portal module placeholder

"""
The `patient_portal` package will implement secure patient bill lookup,
payment processing via Stripe Checkout, viewing of statement history
and secure messaging with agencies.  It should not expose any PHI
directly in URLs or emails; all sensitive information must be
protected behind authenticated portals.

Endpoints for looking up a bill using account number, date of service
and last name, and for initiating a Stripe Checkout session should be
included here.
"""
